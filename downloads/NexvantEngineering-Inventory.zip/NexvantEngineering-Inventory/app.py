"""Nexvant Engineering — local sales and financial management. Python 3.10+."""
import argparse
import base64
import binascii
import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import time
import threading
import webbrowser
from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).parent
DB_PATH = Path(os.environ.get('SALES_DB', ROOT / 'data' / 'sales.db'))
SESSIONS = {}
KINDS = ('invoice', 'quotation', 'purchase_order')
LOGO_LIMIT = 700 * 1024


def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB_PATH, timeout=20)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    return db


def initialize():
    with connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE NOT NULL,salt TEXT NOT NULL,password TEXT NOT NULL,clear_salt TEXT NOT NULL,clear_password TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS parties(id INTEGER PRIMARY KEY,name TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind IN ('customer','supplier')),email TEXT NOT NULL DEFAULT '',phone TEXT NOT NULL DEFAULT '',address TEXT NOT NULL DEFAULT '');
        CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY,name TEXT NOT NULL,sku TEXT UNIQUE NOT NULL,price INTEGER NOT NULL,cost INTEGER NOT NULL,stock INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS documents(id INTEGER PRIMARY KEY,kind TEXT NOT NULL,number TEXT UNIQUE NOT NULL,party_id INTEGER NOT NULL REFERENCES parties(id),issued TEXT NOT NULL,due TEXT NOT NULL,total INTEGER NOT NULL,cost INTEGER NOT NULL,tax INTEGER NOT NULL,notes TEXT NOT NULL,received INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS lines(id INTEGER PRIMARY KEY,document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,product_id INTEGER NOT NULL REFERENCES products(id),name TEXT NOT NULL,qty INTEGER NOT NULL,price INTEGER NOT NULL,cost INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY,document_id INTEGER NOT NULL REFERENCES documents(id),amount INTEGER NOT NULL,paid TEXT NOT NULL,reference TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY,description TEXT NOT NULL,amount INTEGER NOT NULL,paid TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS document_numbers(number TEXT PRIMARY KEY);
        ''')
        columns = {row['name'] for row in db.execute('PRAGMA table_info(products)')}
        if 'reorder_level' not in columns:
            db.execute('ALTER TABLE products ADD COLUMN reorder_level INTEGER NOT NULL DEFAULT 5')
        db.execute('''CREATE TABLE IF NOT EXISTS stock_adjustments(
            id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id),
            quantity INTEGER NOT NULL, reason TEXT NOT NULL, adjusted TEXT NOT NULL,
            stock_before INTEGER NOT NULL, stock_after INTEGER NOT NULL)''')
        if 'credential_version' not in {row['name'] for row in db.execute('PRAGMA table_info(users)')}:
            db.execute('ALTER TABLE users ADD COLUMN credential_version INTEGER NOT NULL DEFAULT 0')
        defaults = {'company':'Nexvant Engineering','address':'','currency':'INR','invoice_next':'1','quotation_next':'1','purchase_order_next':'1','invoice_prefix':'INV-','quotation_prefix':'QUO-','purchase_order_prefix':'PO-',
                    'logo':'','email':'','phone':'','tax_id':'','bank_details':'','document_terms':''}
        db.executemany('INSERT OR IGNORE INTO settings VALUES (?,?)', defaults.items())
        db.execute("UPDATE settings SET value='Nexvant Engineering' WHERE key='company' AND value='Your company'")
        db.execute('INSERT OR IGNORE INTO document_numbers SELECT number FROM documents')


def password_hash(password, salt):
    return hashlib.pbkdf2_hmac('sha256', password.encode(), bytes.fromhex(salt), 260000).hex()


def check_password(password, salt, expected):
    return hmac.compare_digest(password_hash(password, salt), expected)


def required(data, name):
    value = str(data.get(name, '')).strip()
    if not value or len(value) > 2000:
        raise ValueError(f'{name.replace("_", " ").title()} is required (maximum 2000 characters).')
    return value


def update_account(db, user, username, password='', clear_password=''):
    """Validate all credentials before changing this administrator's account."""
    username = required({'username':username}, 'username')
    for value in (password, clear_password):
        if value and not 10 <= len(value) <= 2000:
            raise ValueError('Passwords must contain between 10 and 2000 characters.')
        if value and value != value.strip():
            raise ValueError('Passwords must not start or end with whitespace.')
    if (password and clear_password and password == clear_password
            or password and not clear_password and check_password(password,user['clear_salt'],user['clear_password'])
            or clear_password and not password and check_password(clear_password,user['salt'],user['password'])):
        raise ValueError('Use different login and data clearing passwords.')
    if username == user['username'] and not password and not clear_password:
        raise ValueError('Enter a new username or password.')
    db.execute('UPDATE users SET username=?,credential_version=credential_version+1 WHERE id=?',
               (username,user['id']))
    for value, salt_col, hash_col in [(password,'salt','password'),(clear_password,'clear_salt','clear_password')]:
        if value:
            salt = secrets.token_hex(16)
            db.execute(f'UPDATE users SET {salt_col}=?,{hash_col}=? WHERE id=?',
                       (salt,password_hash(value,salt),user['id']))


def money(value):
    try:
        amount = Decimal(str(value))
        if not amount.is_finite() or amount < 0 or amount > 1000000000:
            raise ValueError('Amount must be between 0 and 1,000,000,000.')
        return int((amount * 100).quantize(Decimal('1'), rounding=ROUND_HALF_UP))
    except InvalidOperation:
        raise ValueError('Enter a valid amount.')


def integer(value, minimum=1):
    result = int(value)
    if str(result) != str(value) or result < minimum or result > 1000000000:
        raise ValueError('Enter a valid whole number.')
    return result


def valid_date(value):
    return date.fromisoformat(str(value)).isoformat()


def validate_logo(value):
    """Accept small raster data URLs only; SVG/remote URLs are deliberately excluded."""
    if not value:
        return ''
    if not isinstance(value, str) or len(value) > (LOGO_LIMIT + 2) // 3 * 4 + 40:
        raise ValueError('Logo must be a PNG, JPEG, or WebP image under 700 KiB.')
    header, separator, encoded = value.partition(',')
    if not separator or header not in ('data:image/png;base64', 'data:image/jpeg;base64', 'data:image/webp;base64'):
        raise ValueError('Upload a PNG, JPEG, or WebP logo.')
    try:
        image = base64.b64decode(encoded, validate=True)
    except (ValueError, binascii.Error):
        raise ValueError('Logo contains invalid image data.') from None
    signatures = {
        'data:image/png;base64': image.startswith(b'\x89PNG\r\n\x1a\n'),
        'data:image/jpeg;base64': image.startswith(b'\xff\xd8\xff'),
        'data:image/webp;base64': image.startswith(b'RIFF') and image[8:12] == b'WEBP',
    }
    if len(image) > LOGO_LIMIT or not signatures[header]:
        raise ValueError('Logo must be a PNG, JPEG, or WebP image under 700 KiB.')
    return value


def rows(db, sql, params=()):
    return [dict(r) for r in db.execute(sql, params)]


def state(db):
    return {'settings':dict(db.execute('SELECT key,value FROM settings').fetchall()),
            'parties':rows(db,'SELECT * FROM parties ORDER BY name'),
            'adjustments':rows(db,'''SELECT a.*,p.name product_name,p.sku FROM stock_adjustments a JOIN products p ON p.id=a.product_id ORDER BY a.id DESC'''),
            'products':rows(db,'SELECT * FROM products ORDER BY name'),
            'documents':rows(db,'''SELECT d.*,p.name party_name,p.kind party_kind,COALESCE((SELECT SUM(amount) FROM payments WHERE document_id=d.id),0) paid FROM documents d JOIN parties p ON p.id=d.party_id ORDER BY d.id DESC'''),
            'lines':rows(db,'SELECT * FROM lines'), 'payments':rows(db,'SELECT * FROM payments ORDER BY paid,id'),
            'expenses':rows(db,'SELECT * FROM expenses ORDER BY paid DESC')}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        # Avoid logging query strings, cookies, or request payloads.
        pass

    def session(self):
        cookie = self.headers.get('Cookie', '')
        token = next((v.strip()[8:] for v in cookie.split(';') if v.strip().startswith('session=')), '')
        session = SESSIONS.get(token)
        if not session or session['expires'] < time.time():
            SESSIONS.pop(token, None)
            return None
        with connect() as db:
            user = db.execute('SELECT credential_version FROM users WHERE id=?',(session['user_id'],)).fetchone()
        if not user or session.get('credential_version') != user['credential_version']:
            SESSIONS.pop(token, None)
            return None
        return session

    def do_GET(self):
        path = self.path.split('?')[0]
        if path == '/api/status':
            with connect() as db:
                return self.send(200, {'setup':not bool(db.execute('SELECT 1 FROM users').fetchone()),'authenticated':bool(self.session())})
        if path.startswith('/api/'):
            session = self.session()
            if not session:
                return self.send(401, {'error':'Please log in.'})
            with connect() as db:
                if path == '/api/state':
                    result = state(db)
                    result['account'] = dict(db.execute('SELECT username FROM users WHERE id=?',
                                                       (session['user_id'],)).fetchone())
                    return self.send(200, result)
                if path == '/api/backup':
                    return self.send(200, {'version':1, 'exported':date.today().isoformat(), **state(db)})
            return self.send(404, {'error':'Not found.'})
        files = {'/':('index.html','text/html; charset=utf-8'), '/app.js':('app.js','text/javascript; charset=utf-8'), '/style.css':('style.css','text/css; charset=utf-8')}
        if path not in files:
            return self.send(404, {'error':'Not found.'})
        filename, mime = files[path]
        self.send(200, (ROOT / 'static' / filename).read_bytes(), mime)

    def do_POST(self):
        # Browsers must submit JSON and match this server's origin; no CORS is enabled.
        origin = self.headers.get('Origin')
        if origin and origin not in ('http://' + self.headers.get('Host',''), 'https://' + self.headers.get('Host','')):
            return self.send(403, {'error':'Invalid request origin.'})
        if self.headers.get('Content-Type','').split(';')[0] != 'application/json':
            return self.send(415, {'error':'JSON required.'})
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 1000000:
                raise ValueError('Invalid request size.')
            data = json.loads(self.rfile.read(length))
            if not isinstance(data, dict):
                raise ValueError('JSON object required.')
            with connect() as db:
                db.execute('BEGIN IMMEDIATE')
                result = self.mutate(db, self.path, data)
            self.send(200, result)
        except (ValueError, KeyError, TypeError, OverflowError, sqlite3.IntegrityError) as exc:
            self.send(400, {'error':str(exc)})
        except PermissionError as exc:
            self.send(401, {'error':str(exc)})

    def mutate(self, db, path, data):
        if path == '/api/setup':
            if db.execute('SELECT 1 FROM users').fetchone():
                raise ValueError('An administrator already exists.')
            username = required(data,'username')
            password, clear = required(data,'password'), required(data,'clear_password')
            if min(len(password),len(clear)) < 10:
                raise ValueError('Both passwords must contain at least 10 characters.')
            if password == clear:
                raise ValueError('Use different login and data clearing passwords.')
            salt, clear_salt = secrets.token_hex(16), secrets.token_hex(16)
            db.execute('INSERT INTO users(id,username,salt,password,clear_salt,clear_password) VALUES(1,?,?,?,?,?)',
                       (username,salt,password_hash(password,salt),clear_salt,password_hash(clear,clear_salt)))
            return {'ok':True}
        if path == '/api/login':
            # Limit brute-force attempts per client without retaining credentials.
            attempts = getattr(self.server, 'attempts', {})
            self.server.attempts = attempts
            key = self.client_address[0]
            recent = [t for t in attempts.get(key,[]) if t > time.time()-60]
            attempts[key] = recent
            if len(recent) >= 10:
                raise PermissionError('Too many attempts. Try again in one minute.')
            user = db.execute('SELECT * FROM users WHERE username=?',(data.get('username',''),)).fetchone()
            if not user or not check_password(str(data.get('password','')),user['salt'],user['password']):
                recent.append(time.time())
                raise PermissionError('Invalid username or password.')
            token = secrets.token_urlsafe(32)
            SESSIONS[token] = {'user_id':user['id'],'expires':time.time()+8*3600,
                               'credential_version':user['credential_version']}
            self.session_cookie = f'session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800'
            return {'ok':True}
        session = self.session()
        if not session:
            raise PermissionError('Please log in.')
        if path == '/api/logout':
            for token, value in list(SESSIONS.items()):
                if value is session:
                    del SESSIONS[token]
            return {'ok':True}
        if path == '/api/parties':
            kind = required(data,'kind')
            if kind not in ('customer','supplier'):
                raise ValueError('Invalid account type.')
            db.execute('INSERT INTO parties(name,kind,email,phone,address) VALUES(?,?,?,?,?)',(required(data,'name'),kind,str(data.get('email','')),str(data.get('phone','')),str(data.get('address',''))))
        elif path == '/api/products':
            db.execute('INSERT INTO products(name,sku,price,cost,stock) VALUES(?,?,?,?,?)',(required(data,'name'),required(data,'sku'),money(data['price']),money(data['cost']),integer(data['stock'],0)))
        elif path == '/api/product-update':
            product = db.execute('SELECT * FROM products WHERE id=?',(data['id'],)).fetchone()
            if not product:
                raise ValueError('Product not found.')
            db.execute('UPDATE products SET name=?,sku=?,price=?,reorder_level=? WHERE id=?',
                       (required(data,'name'),required(data,'sku'),money(data['price']),integer(data['reorder_level'],0),product['id']))
        elif path == '/api/stock-adjustments':
            product = db.execute('SELECT * FROM products WHERE id=?',(data['product_id'],)).fetchone()
            if not product:
                raise ValueError('Product not found.')
            raw = str(data['quantity'])
            quantity = int(raw)
            if str(quantity) != raw or quantity == 0 or abs(quantity) > 1000000000:
                raise ValueError('Enter a nonzero whole quantity, positive or negative.')
            stock = product['stock'] + quantity
            if not 0 <= stock <= 1000000000:
                raise ValueError('Adjustment would put stock outside the allowed range.')
            reason, adjusted = required(data,'reason'), valid_date(data['adjusted'])
            db.execute('UPDATE products SET stock=? WHERE id=?',(stock,product['id']))
            db.execute('INSERT INTO stock_adjustments(product_id,quantity,reason,adjusted,stock_before,stock_after) VALUES(?,?,?,?,?,?)',
                       (product['id'],quantity,reason,adjusted,product['stock'],stock))
        elif path == '/api/documents':
            kind = required(data,'kind')
            if kind not in KINDS:
                raise ValueError('Invalid document type.')
            party = db.execute('SELECT * FROM parties WHERE id=?',(data['party_id'],)).fetchone()
            if not party or party['kind'] != ('supplier' if kind == 'purchase_order' else 'customer'):
                raise ValueError('Choose the correct customer or supplier account.')
            issued, due = valid_date(data['issued']),valid_date(data['due'])
            if due < issued:
                raise ValueError('Due date must be on or after the issue date.')
            items = data['items']
            if not isinstance(items,list) or not 1 <= len(items) <= 100:
                raise ValueError('Add between 1 and 100 line items.')
            lines, quantities, subtotal, cost = [], {}, 0, 0
            for item in items:
                product = db.execute('SELECT * FROM products WHERE id=?',(item['product_id'],)).fetchone()
                if not product:
                    raise ValueError('Product not found.')
                qty, price = integer(item['qty']),money(item['price'])
                quantities[product['id']] = quantities.get(product['id'],0)+qty
                subtotal += qty*price
                cost += qty*product['cost']
                if max(subtotal, cost) > 2**63 - 1:
                    raise ValueError('Document amount exceeds the supported accounting limit.')
                lines.append((product['id'],product['name'],qty,price,product['cost']))
            if kind == 'invoice':
                for pid, qty in quantities.items():
                    if db.execute('SELECT stock FROM products WHERE id=?',(pid,)).fetchone()['stock'] < qty:
                        raise ValueError('Insufficient inventory. Receive a purchase order first.')
                    db.execute('UPDATE products SET stock=stock-? WHERE id=?',(qty,pid))
            settings = dict(db.execute('SELECT key,value FROM settings').fetchall())
            number = settings[kind+'_prefix'] + str(int(settings[kind+'_next'])).zfill(5)
            if db.execute('SELECT 1 FROM document_numbers WHERE number=?', (number,)).fetchone():
                raise ValueError('This document number was already issued. Choose an unused next number in Settings.')
            db.execute('INSERT INTO document_numbers VALUES (?)', (number,))
            tax = money(data.get('tax',0))
            if subtotal + tax > 2**63 - 1:
                raise ValueError('Document amount exceeds the supported accounting limit.')
            cursor = db.execute('INSERT INTO documents(kind,number,party_id,issued,due,total,cost,tax,notes) VALUES(?,?,?,?,?,?,?,?,?)',(kind,number,party['id'],issued,due,subtotal+tax,cost,tax,str(data.get('notes',''))))
            db.executemany('INSERT INTO lines(document_id,product_id,name,qty,price,cost) VALUES(?,?,?,?,?,?)',[(cursor.lastrowid,*line) for line in lines])
            db.execute('UPDATE settings SET value=? WHERE key=?',(str(int(settings[kind+'_next'])+1),kind+'_next'))
        elif path == '/api/receive':
            doc = db.execute('SELECT * FROM documents WHERE id=?',(data['id'],)).fetchone()
            if not doc or doc['kind'] != 'purchase_order' or doc['received']:
                raise ValueError('Only an unreceived purchase order can be received.')
            for line in db.execute('SELECT * FROM lines WHERE document_id=?',(doc['id'],)).fetchall():
                product = db.execute('SELECT * FROM products WHERE id=?',(line['product_id'],)).fetchone()
                stock = product['stock']+line['qty']
                avg = int((Decimal(product['stock']*product['cost']+line['qty']*line['price'])/stock).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
                db.execute('UPDATE products SET stock=?,cost=? WHERE id=?',(stock,avg,product['id']))
            db.execute('UPDATE documents SET received=1 WHERE id=?',(doc['id'],))
        elif path == '/api/payments':
            doc = db.execute('SELECT * FROM documents WHERE id=?',(data['document_id'],)).fetchone()
            if not doc or doc['kind'] == 'quotation':
                raise ValueError('Choose an invoice or purchase order.')
            paid = db.execute('SELECT COALESCE(SUM(amount),0) FROM payments WHERE document_id=?',(doc['id'],)).fetchone()[0]
            amount = money(data['amount'])
            if amount <= 0 or amount > doc['total']-paid:
                raise ValueError('Payment must be positive and cannot exceed the outstanding balance.')
            db.execute('INSERT INTO payments(document_id,amount,paid,reference) VALUES(?,?,?,?)',(doc['id'],amount,valid_date(data['paid']),str(data.get('reference',''))))
        elif path == '/api/expenses':
            amount = money(data['amount'])
            if amount <= 0:
                raise ValueError('Expense must be positive.')
            db.execute('INSERT INTO expenses(description,amount,paid) VALUES(?,?,?)',(required(data,'description'),amount,valid_date(data['paid'])))
        elif path == '/api/settings':
            for key in ('company','address','currency','email','phone','tax_id','bank_details','document_terms','logo'):
                if key not in data:
                    continue
                value = str(data[key])
                if key in ('company','currency') and not value.strip():
                    raise ValueError(f'{key} is required.')
                if key == 'currency' and (len(value) != 3 or not value.isalpha()):
                    raise ValueError('Use a three-letter currency code.')
                if key == 'logo':
                    value = validate_logo(value)
                elif len(value) > 2000:
                    raise ValueError(f'{key} must be 2000 characters or fewer.')
                db.execute('UPDATE settings SET value=? WHERE key=?',(value,key))
            current = dict(db.execute('SELECT key,value FROM settings').fetchall())
            proposed = set()
            for kind in KINDS:
                counter = integer(data.get(kind+'_next', current[kind+'_next']))
                prefix = str(data.get(kind+'_prefix', current[kind+'_prefix'])).strip()
                if len(prefix)>30:
                    raise ValueError('Prefixes must be 30 characters or fewer.')
                number = prefix+str(counter).zfill(5)
                if number in proposed or db.execute('SELECT 1 FROM document_numbers WHERE number=?',(number,)).fetchone():
                    raise ValueError('This starting number is already used or conflicts with another document type.')
                proposed.add(number)
                db.execute('UPDATE settings SET value=? WHERE key=?',(str(counter),kind+'_next'))
                db.execute('UPDATE settings SET value=? WHERE key=?',(prefix,kind+'_prefix'))
        elif path == '/api/passwords':
            user = db.execute('SELECT * FROM users WHERE id=?',(session['user_id'],)).fetchone()
            attempts = getattr(self.server, 'account_attempts', {})
            self.server.account_attempts = attempts
            key = self.client_address[0]
            recent = [t for t in attempts.get(key,[]) if t > time.time()-60]
            attempts[key] = recent
            if len(recent) >= 5:
                raise PermissionError('Too many attempts. Try again in one minute.')
            if not check_password(str(data.get('current_password','')),user['salt'],user['password']):
                recent.append(time.time())
                raise PermissionError('Current login password is incorrect.')
            for name in ('password','clear_password'):
                if 'confirm_'+name in data and data.get(name,'') != data['confirm_'+name]:
                    raise ValueError('The new password and its confirmation must match.')
            update_account(db, user, data.get('username',user['username']),
                           str(data.get('password','')), str(data.get('clear_password','')))
            SESSIONS.clear()
            self.session_cookie = 'session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'
        elif path == '/api/clear':
            user=db.execute('SELECT * FROM users WHERE id=?',(session['user_id'],)).fetchone()
            attempts = getattr(self.server, 'clear_attempts', {})
            self.server.clear_attempts = attempts
            key = session['user_id']
            recent = [t for t in attempts.get(key, []) if t > time.time()-60]
            attempts[key] = recent
            if len(recent) >= 5:
                raise PermissionError('Too many clearing attempts. Try again in one minute.')
            if data.get('confirmation') != 'CLEAR ALL DATA' or not check_password(str(data.get('password','')),user['clear_salt'],user['clear_password']):
                recent.append(time.time())
                raise PermissionError('Clearing password or confirmation is incorrect.')
            for table in ('stock_adjustments','payments','lines','documents','expenses','products','parties'):
                db.execute(f'DELETE FROM {table}')
            # Keep login, company details, and numbering to avoid reuse of issued numbers.
        else:
            raise ValueError('Unknown action.')
        return {'ok':True}

    def send(self, status, payload, content_type='application/json'):
        body = json.dumps(payload).encode() if content_type == 'application/json' else payload
        self.send_response(status)
        if getattr(self, 'session_cookie', None):
            self.send_header('Set-Cookie', self.session_cookie)
        self.send_header('Content-Type',content_type)
        self.send_header('Content-Length',str(len(body)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data:; object-src 'none'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(body)


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--host',default='127.0.0.1')
    parser.add_argument('--port',type=int,default=8000)
    parser.add_argument('--open-browser', action='store_true', help='Open the local application in your default browser')
    args=parser.parse_args()
    initialize()
    server = ThreadingHTTPServer((args.host,args.port),Handler)
    print(f'Nexvant Engineering running at http://{args.host}:{args.port}',flush=True)
    if args.open_browser:
        threading.Timer(0.5, webbrowser.open, args=(f'http://127.0.0.1:{args.port}',)).start()
    server.serve_forever()
