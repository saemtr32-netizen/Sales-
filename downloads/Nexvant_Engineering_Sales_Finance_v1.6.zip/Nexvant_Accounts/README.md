# Nexvant Engineering — Sales & Finance 1.6

An offline, single-administrator business manager using your supplied Nexvant logo. The invoice layout now follows the uploaded 207-ICF example: a monochrome grid with consignee/buyer blocks, invoice/order/dispatch details, item columns, HSN-wise tax summary, amount in words, declaration, bank details and authorised signature area.

## What is ready

- `Nexvant_Accounts.html`: self-contained software for Edge/Chrome on Windows; responsive screens for mobile-size displays.
- `Start_Nexvant_Windows.cmd`: opens that file in an Edge app-style window, or your default browser. This is a browser-based Windows package, not a native EXE installer.
- `android/`: native Android WebView application source with embedded offline software, Android printing, backup export and file import. **No compiled APK is included.** It has not been compiled or tested on an Android device in this environment.
- `app/` and `assets/`: editable source and original logo; `build.py` rebuilds the self-contained HTML with Python 3.
- `tests/`: accounting and encryption checks, runnable with Node.js. No customer data or fixed administrator password is shipped.

## Start on Windows

1. Extract the entire ZIP to a permanent folder, such as `Documents\Nexvant_Accounts`.
2. Double-click `Start_Nexvant_Windows.cmd`. Alternatively, right-click `Nexvant_Accounts.html` and open it with Microsoft Edge or Google Chrome.
3. Create your own administrator password (at least 10 characters). There is no default password. Enable a recovery key in Settings before you need password reset.
4. In **Settings**, enter Nexvant's registered address, GSTIN, phone, email and bank details. The SHS sample's identity, GSTIN, bank account and signature have NOT been copied into Nexvant's records.
5. Set the prefixes and starting numbers for invoices and quotations. For example, prefix `NVE/26-27/` and next number `62` creates `NVE/26-27/062`. The software skips numbers already used, including voided documents.
6. Add Customers, Suppliers and Inventory items. Enter opening stock, selling price and standard cost per unit.
7. Create an invoice, quotation or purchase order. Use **Custom item / service** for items that should not change stock.
8. Export an encrypted backup after each working day.

Keep the HTML in the same folder and use the same browser profile. Moving the file, switching browsers, clearing browser data or uninstalling the Android app can make stored records unavailable. Restore a backup in the new location if needed. Do not use private/incognito mode. The HTML file does not itself contain your accounts: the encrypted records are held by your browser.

## Normal workflows

### Quotation to sale
Create a quotation, review it and print it. Choose **Convert** to prepare an invoice. Check the invoice date, due date, shipping address, tax split and cost per unit, then save. Conversion prepares a new document; it does not cancel the original quotation. Avoid converting the same quotation twice accidentally.

### Purchase to stock
A purchase order has no accounting or stock effect. Convert it to a supplier bill when goods are received, enter the supplier's actual invoice reference, and save. Supplier bills increase inventory and supplier payables. Recording a supplier payment reduces the payable. Purchase costs are not automatically averaged into item costs: update standard cost in Inventory when appropriate.

### Receipts and payments
Open **Payments**, select an outstanding sales invoice or supplier bill, enter the payment date, amount, method and reference, then save. Partial payments are supported. Overpayments and payments dated before the linked document are rejected. Advances, unallocated receipts and bank reconciliation are not included.

### Customer or supplier statement
Open the account and choose **Statement**, or use **Reports**. Statements show all recorded invoices/bills, payments, running balance, due dates, overdue days and remaining balances. Choose **Print / Save PDF**. Reports use all recorded transactions; future-dated records are included in account statements.

### Corrections
Customer, supplier, item and company details are editable. Issued documents retain a snapshot of company and party details. To correct a posted document, void linked payments first, then void the document and create a replacement. Voiding requires the administrator password. Voided records remain visible. A supplier bill cannot be voided if doing so would make stock negative.

### Stock and profit
Stock = opening quantity + supplier bills + adjustments − invoices. Quotations and purchase orders do not change stock. Duplicate stock lines on an invoice are checked together to prevent overselling. Stock supports three decimal places; currency uses two.

Profit & loss uses invoice dates: sales excluding GST minus the **manual cost per unit stored on each sales line**, minus operating expenses. If costs are left at zero, profit will be overstated. Enter actual/standard costs before issuing invoices. The report does not implement full double-entry accounts, automatic FIFO/weighted-average costing, depreciation, statutory tax returns, e-invoicing or payroll. Stock adjustments have no automatic P&L effect; record associated expenses separately if needed.

GST rates and IGST versus CGST+SGST are chosen manually. The program does not determine place of supply or tax eligibility. Verify invoice details before issue. Unlike the sample bill's whole-rupee total, this version retains paise and shows exact two-decimal totals (for example, 424860 + 18% = 501334.80).

## Printing

Use **View / Print** on a document. Choose A4 portrait, turn off browser headers and footers, and use normal print scaling. Use Save as PDF for an electronic copy. Long invoices continue over additional pages. On a phone the invoice preview scrolls horizontally to preserve its print layout; data-entry screens adapt to the narrow display. The signature area is blank for authorised signing.

## Security, backups and data clearing

- The workspace and backup JSON use AES-GCM encryption with a PBKDF2-derived key. The password is not stored in plain text.
- There is one administrator, and that administrator's password is also required to clear data, void entries and adjust stock.
- Accounts lock after 15 minutes without interaction. Use **Lock** before leaving the device.
- **Settings → Download encrypted backup** exports the entire workspace.
- **Restore backup** replaces, rather than merges, records. Existing records require their current password before replacement. Then enter the backup's original password. A forgotten password can be reset using a recovery key previously enabled for that workspace. Without either the password or its saved recovery key, encrypted records cannot be decrypted.
- Changing your password does not change old backup files. Make a fresh backup after a password change.
- **Clear all business data** requires the password plus a second confirmation. It removes parties, documents, payments, expenses, inventory and stock adjustments. Company settings, numbering counters and the password remain. Keep a backup first.
- This version has no cloud sync or simultaneous multi-user access. To move between Windows and Android, export on the source device and restore on the destination. Keep one authoritative device at a time to avoid conflicting copies.
- Local browser storage has a size limit. A failed save displays an error and leaves the prior encrypted records in place. Back up regularly and avoid running multiple tabs.

## Android: build an installable APK on Windows

The included project is source code, not an APK. The build environment used here had no Android SDK, so compilation, installation, backup integration and native printing still require device testing.

1. Install Android Studio from https://developer.android.com/studio.
2. Open SDK Manager and install **Android SDK Platform 35**, Build Tools and Platform Tools. Finish SDK setup and accept the SDK licences in Android Studio.
3. Open the `android` directory as a project. The project uses Android Gradle Plugin 8.7.3, Gradle 8.9 and Java 17 or a compatible Android Studio runtime.
4. Run `android\BUILD_APK_WINDOWS.cmd`. It uses the default Windows SDK location, or your `ANDROID_HOME` setting. It downloads Gradle 8.9 from its official distribution service, checks the published SHA-256 checksum, and builds a debug APK. Internet access is required for this first build and dependencies.
5. The APK output is `android\app\build\outputs\apk\debug\app-debug.apk`.
6. Copy it to an Android 9+ phone, open it and approve installation from that file source if prompted. Use an up-to-date Android System WebView. Create a password or restore your Windows backup.
7. Before real use, test login, saving a customer and invoice, reopening the app, export/restore and printing on your phone.

The debug APK is for local testing. For durable distribution, generate a signed release APK in Android Studio and retain its signing key for future updates. This project has not been submitted to Google Play. It requests no Internet or broad storage permission; backup files use the Android file picker.

Official build references:
- https://developer.android.com/build/releases/agp-8-7-0-release-notes
- https://docs.gradle.org/8.9/release-notes.html
- https://developer.android.com/reference/android/webkit/WebViewClient

## Validation completed

19 accounting checks passed, covering tax totals, numbering, invalid input, stock movements, partial payments, overpayments, void effects, report dates, amount wording and fractional quantities. Five encryption checks passed: encrypted persistence, restore round trip, wrong-password rejection, tamper rejection and unique encryption nonces. Desktop dashboard, sample invoice and 390px mobile layout were inspected in a browser using a disposable fixture. Live browser persistence could not be exercised in the HTTP-only preview; cryptographic persistence was tested separately with Node's WebCrypto. Native Windows launcher, Android compilation/device behavior and physical/PDF print output were not tested here.

Run checks: `node tests/accounting.test.js` and `node tests/security.test.js`.
Rebuild with `python build.py` after editing app source; this updates the HTML and Android asset. Do not delete the assets folder.

## Version 1.1 invoice improvements

The document editor now has adjacent Bill To and Ship To panels. Selecting an account fills its billing name, address and GSTIN; you can override those fields on the document without changing the customer master. Use Copy Bill To → Ship To when both addresses match. HSN/SAC remains editable on each item line, and the amount in words now updates while entering items as well as appearing on the printed invoice.

Settings now provides separate account holder name, bank account number, bank name, branch, IFSC and MICR fields. Enter Nexvant's actual details there; no payment information has been copied from the SHS example. Previous free-text bank details are retained as payment instructions. New documents snapshot these settings; previously issued documents retain their original saved details.

Before upgrading, download an encrypted backup. Replace Nexvant_Accounts.html in its existing location, keeping the same browser profile. If records are not visible, restore the backup with its original password. The data format and password remain compatible with version 1.0. Android source has been updated to version 1.1, but no APK is included.

Version 1.1 field/rendering tests also passed for billing autofill/copy, billing overrides, HSN/SAC, amount-in-words preview, structured bank output, leading-zero preservation, saved document snapshots and legacy bank-detail fallback. A fresh browser run was attempted but the browser binary download was invalid; version 1.1 browser/PDF output has not been visually reverified. Run `node tests/invoice-fields.test.js` for the new checks.

## Version 1.2 — earlier payment dates

Payments → Record receipt / payment now explicitly labels the Actual payment date field as allowing past dates. Choose the date the money was actually received or paid. There is no limit on how far back you can record a payment, provided it is on or after its linked invoice/bill date. To enter an older transaction, first create the invoice/bill with its original document date.

The payment list is sorted by actual payment date, newest first. Customer/supplier statements use this actual date. If a payment was previously saved with the wrong date, choose Change date, enter the correct date and a reason, and authorise with your administrator password. The amount remains unchanged. Correction history and the entry timestamp (for new payments) are retained in the encrypted data. Previously saved payments remain compatible.

Back up before replacing the HTML in its existing location. Android source is updated; no compiled APK is included.

Version 1.2 checks: historical payment dates, valid leap days, invalid-date rejection and before-document rejection passed, along with existing accounting, encryption and invoice-field checks. Automated browser testing was attempted but the environment denied Chromium the socket access required to launch; the new payment-date UI has not been browser-verified.

## Version 1.3 — 207-ICF-style bill template

The new black-and-white invoice uses the supplied reference's layout while keeping Nexvant branding and existing accounting data. The top section contains company, consignee (Ship to), buyer (Bill to), invoice date/number, payment terms, reference, buyer order/date, delivery note/date, dispatch document, transport mode, destination, LR/RR number, vehicle number, e-Way bill number and delivery terms. These optional document fields are available in Order & dispatch details when creating documents. Existing documents show dashes for fields not previously captured.

Items are followed by GST totals, amount in words, an HSN-and-rate-wise tax summary, tax amount in words, company bank details and signature. Company registration details and an optional declaration can be entered in Settings. Use Print / Save All 3 Copies to print all three copy labels in one job, or choose a label and Print / Save Selected Copy for one copy. New settings are saved on newly issued documents; existing document snapshots remain unchanged. The reference's unnecessary blank continuation page is not reproduced; long item lists continue naturally.

This is a layout change, not GST portal integration. No IRN, acknowledgement, e-invoice QR code or sample-party details are copied or fabricated. The e-Way bill field displays a number you already have; the software does not generate one. The reference's discount column is omitted because discount calculation is not implemented. Item rates remain the actual billed unit rates.

Checks: existing accounting, encryption, invoice-field and historical-payment checks pass. The new print layout has not been visually verified in a browser or on a physical printer in this environment. Preview a sample and use A4 portrait before issuing invoices.

## Version 1.4 — declaration, PAN and GST states

Payment Due Date is removed from the printed bill. Internal due dates are retained for pending-payment tracking and statements. Company PAN prints above the declaration in the left footer. The declaration supplied by the user is the default for new settings and for blank declarations on older invoices. Existing custom declarations remain editable in Settings. Notes are printed separately.

Enter the company's GSTIN in Settings. For a recognised state prefix and standard GSTIN-shaped input, the software fills the official state name/code and extracts the PAN segment. Buyer state is derived from Billing GSTIN; consignee state uses the new Consignee GSTIN field, or a GSTIN already present in the shipping address. Manual state selection is available when there is no GSTIN. Unknown prefixes are not guessed. No PAN or GSTIN from the sample supplier has been imported.

This is an offline state-code mapping and PAN extraction, not a live taxpayer search, checksum validation or confirmation of GST registration. The mapping uses the official NIC e-Way Bill state-code master for Indian states/UTs and Other Territory (97). Non-Indian country codes are not treated as domestic GSTIN prefixes.
Sources checked 13 November 2026:
- https://docs.ewaybillgst.gov.in/apidocs/state-code.html
- https://www.dor.gov.in/files/inline-documents/Report_on_GST_Registration.pdf (GSTIN positions 1–2 state; 3–12 PAN).

Checks passed: removal of printed due date, default declaration with separate notes, PAN placement/extraction, Tamil Nadu 33, Maharashtra 27, Karnataka 29 and invalid prefix handling, plus prior accounting/encryption tests. Browser visual verification remains incomplete.

## Version 1.5 — all three invoice copies in one click

Open an invoice with View / Print, then click Print / Save All 3 Copies. A single print dialog includes Original for Recipient, Duplicate for Transporter and Triplicate for Supplier, in that order. Select your printer or Save as PDF to create one combined file. Each copy starts on a new page; long invoices may occupy more than one page per copy. Keep the print dialog's Copies setting at 1, since the document already contains all three labelled versions.

To print only one version, choose its label and click Print / Save Selected Copy. Clicking the all-copies button repeatedly rebuilds exactly three copies. This only changes printing; it does not create three sales records or change stock/payments. Android source uses the same combined page through its print interface; a compiled APK is still not included. Browser/Android confirmation of printing or saving is still required.

Checks passed for all three labels, one print invocation, repeat-click stability, selected-copy reset and removal of duplicated element IDs. Accounting/encryption checks also passed. Browser and physical/PDF print layout verification remains incomplete.


## Version 1.6 — password reset and automatic backups

Before upgrading, download an encrypted backup. Replace `Nexvant_Accounts.html` at its existing location using the same browser profile, or restore your exported backup. Existing version 1.x records remain compatible. Android bundled HTML is updated; no compiled APK is included.

### Enable and use password reset

1. Unlock your workspace, open **Settings → Password recovery → Create recovery key** and confirm your current password.
2. Save the recovery key file somewhere private, separate from your backups. Anyone with the key and encrypted workspace can reset its password. The key is not emailed or sent to a server.
3. If you forget your password, choose **Forgot password / Reset password** on the unlock screen. Enter your saved recovery key and enter the new password twice (at least 10 characters).
4. Reset preserves your customers, invoices, stock, payments, settings and numbering. Download a new encrypted backup afterwards.

Existing workspaces must enable recovery while unlocked. This update cannot reset an already-forgotten password on an older workspace that has no recovery key. Replacing a recovery key changes future saves; older backups still require their original password/key. Recovery is tied to the encrypted vault: it cannot retrieve browser data that was deleted. Do not include your recovery key in support messages.

### Configure automatic backups

Open **Settings → Automatic backup settings**. Turn backups **On**, choose every **15 minutes**, **hour**, or **day**, and retain **3**, **7**, or **14** snapshots. Saving enabled settings creates the first snapshot immediately. Later snapshots are checked every 30 seconds while unlocked; a due snapshot is also saved after a successful edit. Timing can be delayed by browser throttling or device sleep. **Save snapshot now** works even with scheduling turned off.

Snapshots are AES-GCM encrypted, include the full workspace and any recovery envelope, and are retained in this browser on this device. They do not automatically download files, sync to cloud storage or run when the app is closed/locked. Download a saved snapshot to keep an independent copy on a USB drive or another device. Use **Restore backup** to import that downloaded JSON with the password used at the snapshot date. Retention removes the oldest local snapshots only; downloaded files are unaffected. Disabling scheduling keeps existing snapshots.

Clearing browser data, changing browser profiles or uninstalling the Android app removes local snapshots as well as the main workspace. Clearing business records inside the app does not erase retained snapshots or previously downloaded backups. Storage-limit errors are shown; reduce retention and export an independent backup if storage fills. Enabling recovery increases encrypted vault size because it adds a separately encrypted recovery copy.

### Version 1.6 validation

All existing Node accounting, invoice, historical-payment and encryption checks passed. New checks passed for legacy compatibility, password reset preserving invoices/payments/customers, incorrect recovery key and tamper rejection, old-password rejection, old backup compatibility, automatic scheduling/retention, snapshot decryption, locked/disabled behavior and storage failure preservation.

`python3 tests/browser-recovery.py` passed against Chromium using a disposable browser profile and a loopback HTTP server: recovery-key export, wrong-key rejection, reset, new-password unlock, old-password rejection, encrypted snapshot download, persisted backup settings, and desktop/390px mobile layouts. Local-file launch was blocked by the managed browser's policy, so this run used loopback HTTP; test the extracted file in your own current Edge/Chrome browser. Native Windows launcher and Android build/device behavior remain untested.

Rebuild both standalone and Android bundled HTML with `python3 build.py`. Run `node tests/recovery-backup.test.js` for the new security/scheduling checks; existing tests remain under `tests/*.test.js`.
