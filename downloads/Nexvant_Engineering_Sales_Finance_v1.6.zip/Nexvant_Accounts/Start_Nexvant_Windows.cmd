@echo off
setlocal
set "NEXVANT_FILE=%~dp0Nexvant_Accounts.html"
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
 start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="file:///%NEXVANT_FILE:\=/%"
 exit /b
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
 start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="file:///%NEXVANT_FILE:\=/%"
 exit /b
)
start "" "%NEXVANT_FILE%"
