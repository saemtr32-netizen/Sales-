from pathlib import Path
import base64
root=Path(__file__).parent
logo=base64.b64encode((root/'assets/logo.png').read_bytes()).decode()
html='''<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#0e2137"><title>Nexvant Engineering • Sales & Finance</title><style>'''+(root/'app/style.css').read_text()+'''</style></head><body><div id="root"></div><script>const LOGO="data:image/png;base64,'''+logo+'''";</script><script>'''+(root/'app/core.js').read_text()+'''</script><script>'''+(root/'app/app.js').read_text()+'''</script></body></html>'''
(root/'Nexvant_Accounts.html').write_text(html)
(root/'android/app/src/main/assets/index.html').write_text(html)
(root/'preview').mkdir(exist_ok=True)
(root/'preview/index.html').write_text(html)
