"""Run with python3 tests/browser-recovery.py (requires Playwright Chromium). Uses a disposable profile."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json, shutil
import threading
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

root=Path(__file__).resolve().parents[1]
artifacts=Path('/tmp/nexvant-refined-check');artifacts.mkdir(exist_ok=True)
server=ThreadingHTTPServer(('127.0.0.1',0),partial(SimpleHTTPRequestHandler,directory=str(root)))
threading.Thread(target=server.serve_forever,daemon=True).start()
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True, executable_path=shutil.which('chromium') or pw.chromium.executable_path)
    context=browser.new_context(accept_downloads=True,viewport={'width':1365,'height':1000})
    page=context.new_page();errors=[]
    page.on('pageerror',lambda e: errors.append(str(e)))
    page.on('dialog',lambda d:d.accept())
    page.goto(f'http://127.0.0.1:{server.server_port}/Nexvant_Accounts.html')
    page.locator('#authform [name=password]').fill('Original-password-123')
    page.locator('#authform [name=confirm]').fill('Original-password-123')
    page.locator('#authform button').click()
    page.get_by_role('button',name='Settings',exact=True).click()
    page.locator('#settingsform [name=company]').fill('Recovery Test Business')
    page.locator('#settingsform button').click()
    page.locator('#enablerecovery').click()
    page.locator('dialog input').fill('Original-password-123')
    page.locator('dialog button').filter(has_text='Continue').click()
    code=page.locator('#recoverycode').inner_text()
    assert len(code)==53
    with page.expect_download() as info:
        page.locator('#saverecovery').click()
    assert code in Path(info.value.path()).read_text()
    page.locator('#closerecovery').click()
    page.locator('#autoform [name=enabled]').select_option('true')
    page.locator('#autoform [name=minutes]').select_option('15')
    page.locator('#autoform [name=keep]').select_option('3')
    page.locator('#autoform button').click()
    page.get_by_role('button',name='Download snapshot',exact=True).first.wait_for()
    with page.expect_download() as info:
        page.get_by_role('button',name='Download snapshot',exact=True).first.click()
    vault=json.loads(Path(info.value.path()).read_text())
    assert vault['format']=='NexvantEncryptedBackup' and 'recovery' in vault
    assert 'Recovery Test Business' not in json.dumps(vault)
    page.screenshot(path=str(artifacts/'settings-desktop.png'),full_page=True)
    page.locator('#lock').click()
    page.reload()
    page.locator('#forgotpass').click()
    page.locator('#resetform [name=code]').fill('incorrect-key')
    page.locator('#resetform [name=password]').fill('Replacement-password-123')
    page.locator('#resetform [name=confirm]').fill('Replacement-password-123')
    page.get_by_role('button',name='Reset password',exact=True).click()
    page.locator('#reseterr').filter(has_text='incorrect').wait_for()
    page.locator('#resetform [name=code]').fill(code)
    page.get_by_role('button',name='Reset password',exact=True).click()
    page.locator('#lock').wait_for()
    assert page.evaluate('state.settings.company')=='Recovery Test Business'
    page.locator('#lock').click()
    page.locator('#authform [name=password]').fill('Original-password-123')
    page.locator('#authform button').click()
    page.locator('#autherr').filter(has_text='Unable to unlock').wait_for()
    page.locator('#authform [name=password]').fill('Replacement-password-123')
    page.locator('#authform button').click()
    page.locator('#lock').wait_for()
    page.get_by_role('button',name='Settings',exact=True).click()
    assert page.locator('#autoform [name=enabled]').input_value()=='true'
    assert page.locator('#autoform [name=minutes]').input_value()=='15'
    page.set_viewport_size({'width':390,'height':844})
    page.screenshot(path=str(artifacts/'settings-mobile.png'),full_page=True)
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
    page.locator('#lock').click()
    page.locator('#forgotpass').click()
    page.screenshot(path=str(artifacts/'reset-mobile.png'),full_page=True)
    assert not errors,errors
    context.close();browser.close()
server.shutdown()
print('PASS browser: setup, recovery key export, scheduled snapshot/settings persistence, encrypted download, wrong-key rejection, reset preserves business settings, old-password rejection, new-password login and mobile layout')
