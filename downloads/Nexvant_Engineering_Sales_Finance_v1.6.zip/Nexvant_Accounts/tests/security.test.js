const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict'),crypto=require('node:crypto').webcrypto;
const mem=new Map();const ctx={crypto,TextEncoder,TextDecoder,Uint8Array,atob,btoa,structuredClone,console,Accounts:require('../app/core.js'),document:{addEventListener(){}},window:{addEventListener(){}},setInterval(){},localStorage:{setItem(k,v){mem.set(k,v)},getItem(k){return mem.get(k)}}};
vm.createContext(ctx);vm.runInContext(fs.readFileSync(__dirname+'/../app/app.js','utf8').replace(/auth\(\);\s*$/,''),ctx);
vm.runInContext(`(async()=>{
 salt=b64(crypto.getRandomValues(new Uint8Array(16))); key=await derive('Testing-password-123',salt); state=fresh();state.settings.company='Test Secret';
 await commit(state); const v=JSON.parse(localStorage.getItem(KEY));
 if(JSON.stringify(v).includes('Test Secret'))throw Error('Plaintext leak');
 const restored=await unseal(v,'Testing-password-123');if(restored.s.settings.company!=='Test Secret')throw Error('Round trip failed');
 let blocked=false;try{await unseal(v,'Incorrect-password')}catch{blocked=true}if(!blocked)throw Error('Wrong password accepted');
 const corrupt={...v,data:v.data.slice(0,-8)+'AAAAAAAA'};blocked=false;try{await unseal(corrupt,'Testing-password-123')}catch{blocked=true}if(!blocked)throw Error('Tampering accepted');
 const v2=await seal(state);if(v.iv===v2.iv||v.data===v2.data)throw Error('Nonce reused');
 console.log('PASS encrypted persistence, backup round trip, wrong password, tamper rejection, unique IV');
})()`,ctx).catch(e=>{console.error(e);process.exitCode=1});
