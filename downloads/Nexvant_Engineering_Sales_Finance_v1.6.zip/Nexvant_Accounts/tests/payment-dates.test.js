const assert=require('node:assert/strict'),A=require('../app/core.js');
const s={docs:[{id:'i',type:'invoice',date:'2020-01-01',lines:[{qty:1,rate:100,gst:0}]}],payments:[]};
A.validatePayment(s,{doc:'i',date:'2020-01-02',amount:50});
A.validPaymentDate('2024-02-29','2020-01-01');
for(const date of ['','not-date','2023-02-29','2024-13-01','2019-12-31'])assert.throws(()=>A.validPaymentDate(date,'2020-01-01'));
console.log('PASS historic payments, leap day, invalid dates and before-document rejection');
