const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
const mem=new Map();let full=false;
const ctx={crypto:require('node:crypto').webcrypto,TextEncoder,TextDecoder,Uint8Array,atob,btoa,structuredClone,console,Accounts:require('../app/core.js'),document:{addEventListener(){},getElementById(){return {prepend(){}}},createElement(){return {}}},window:{addEventListener(){}},setInterval(){},localStorage:{setItem(k,v){if(full)throw Error('Quota exceeded');mem.set(k,v)},getItem(k){return mem.get(k)}}};
vm.createContext(ctx);vm.runInContext(fs.readFileSync(__dirname+'/../app/app.js','utf8').replace(/auth\(\);\s*$/,''),ctx);
(async()=>{
 await vm.runInContext(`(async()=>{
 salt=b64(crypto.getRandomValues(new Uint8Array(16)));key=await derive('Old-password-123',salt);state=fresh();state.settings.company='Private business';state.parties=[{id:'customer1',kind:'customer',name:'Saved customer'}];state.docs=[{id:'invoice1',type:'invoice',party:'customer1',number:'INV-001',date:'2026-11-01',due:'2026-11-30',lines:[{qty:2,rate:100,gst:18,cost:60,description:'Service'}]}];state.payments=[{id:'payment1',doc:'invoice1',date:'2026-11-02',amount:100}];
 await commit(state); const legacy=JSON.parse(localStorage.getItem(KEY));
 let rejected=false;try{await recoverVault(legacy,'invalid')}catch{rejected=true}if(!rejected)throw Error('Legacy vault accepted recovery');
 const code=await createRecovery(state);await commit(state);const vault=JSON.parse(localStorage.getItem(KEY));
 if(JSON.stringify(vault).includes(code)||JSON.stringify(vault).includes('Private business')||JSON.stringify(vault).includes(state.security.recoveryKey))throw Error('Secret exposed');
 rejected=false;try{await recoverVault(vault,'wrong-key')}catch{rejected=true}if(!rejected)throw Error('Wrong recovery key accepted');
 const corrupt=structuredClone(vault);corrupt.recovery.data='AAAA'+corrupt.recovery.data.slice(4);rejected=false;try{await recoverVault(corrupt,code)}catch{rejected=true}if(!rejected)throw Error('Tampered recovery accepted');
 const recovered=await recoverVault(vault,code.toUpperCase());if(recovered.settings.company!=='Private business')throw Error('Recovery lost data');
 await replacePassword(recovered,'New-password-123');const updated=JSON.parse(localStorage.getItem(KEY));
 const resetResult=await unseal(updated,'New-password-123');if(JSON.stringify(resetResult.s.docs)!==JSON.stringify(recovered.docs)||resetResult.s.payments[0].amount!==100||resetResult.s.parties[0].name!=='Saved customer')throw Error('Business records changed during reset');rejected=false;try{await unseal(updated,'Old-password-123')}catch{rejected=true}if(!rejected)throw Error('Old password still works');
 await recoverVault(updated,code);await unseal(vault,'Old-password-123');
 console.log('PASS legacy compatibility, recovery round trip, wrong key, tamper rejection, secret protection, password reset and old backup compatibility');
 const before=localStorage.getItem(KEY);try{await replacePassword(state,'short')}catch{}if(localStorage.getItem(KEY)!==before)throw Error('Failed reset changed vault');
 state.settings.automaticBackup={enabled:false,minutes:15,keep:3};await commit(state);runAutoBackup();if(savedBackups().length)throw Error('Disabled scheduler ran');
 state.settings.automaticBackup.enabled=true;await commit(state);if(savedBackups().length!==1)throw Error('First snapshot not saved');
 const first=savedBackups()[0].at;runAutoBackup();if(savedBackups()[0].at!==first||savedBackups().length!==1)throw Error('Interval ignored');
 for(let i=0;i<5;i++){state.settings.company='Version '+i;await commit(state);runAutoBackup(true);}
 if(savedBackups().length!==3)throw Error('Retention failed');
 const restored=await unseal(savedBackups()[0].vault,'New-password-123');if(restored.s.settings.company!=='Version 4')throw Error('Snapshot stale');
 const entries=savedBackups();entries[0].at=Date.now()-16*60000;localStorage.setItem(AUTO_KEY,JSON.stringify(entries));runAutoBackup();if(savedBackups()[0].at<=entries[0].at)throw Error('Due snapshot not saved');
 lockForTest=state;state=null;const saved=localStorage.getItem(AUTO_KEY);runAutoBackup(true);if(localStorage.getItem(AUTO_KEY)!==saved)throw Error('Backup ran while locked');state=lockForTest;
 console.log('PASS disabled/locked scheduling, interval, due snapshot, retention and encrypted snapshot restore');
 })()`,Object.assign(ctx,{lockForTest:null}));
 full=true;await vm.runInContext(`(async()=>{const previous=localStorage.getItem(KEY);let rejected=false;try{await replacePassword(state,'Another-password-123')}catch{rejected=true}if(!rejected||localStorage.getItem(KEY)!==previous)throw Error('Failed storage write replaced vault');runAutoBackup(true);if(!backupError)throw Error('Backup failure not reported');})()`,ctx);
 console.log('PASS storage failure preserves vault and reports backup error');
})().catch(e=>{console.error(e);process.exitCode=1});
