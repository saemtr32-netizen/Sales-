const assert=require('node:assert/strict'),A=require('../app/core.js');
let count=0;function check(name,fn){fn();count++;console.log('PASS',name)}
const s={settings:{numbers:{invoice:{prefix:'INV-',next:62}}},parties:[{id:'c',kind:'customer'},{id:'s',kind:'supplier'}],items:[{id:'i',name:'Panel',opening:10}],docs:[],payments:[],expenses:[],adjustments:[]};
const d={id:'d',type:'invoice',party:'c',date:'2026-11-01',due:'2026-11-30',lines:[{item:'i',description:'Panel',qty:2,rate:100,gst:18,cost:60}]};
check('GST and grand total',()=>assert.deepEqual(A.total(d),{base:200,tax:36,total:236}));
check('Document validation',()=>A.validateDoc(s,d));
check('Duplicate stock lines cannot oversell',()=>assert.throws(()=>A.validateDoc(s,{...d,lines:[{...d.lines[0],qty:6},{...d.lines[0],qty:6}]}),/Insufficient/));
check('Invalid date order rejected',()=>assert.throws(()=>A.validateDoc(s,{...d,due:'2026-10-30'}),/Due date/));
check('Negative rate rejected',()=>assert.throws(()=>A.validateDoc(s,{...d,lines:[{...d.lines[0],rate:-1}]})));
check('Wrong account kind rejected',()=>assert.throws(()=>A.validateDoc(s,{...d,party:'s'})));
check('Configured numbering and duplicate skip',()=>{assert.equal(A.number(s,'invoice'),'INV-062');s.docs.push({...d,id:'dummy',number:'INV-063',type:'quote'});assert.equal(A.number(s,'invoice'),'INV-064')});
s.docs.push(d);
check('Invoice decrements stock; quote does not',()=>assert.equal(A.stock(s,'i'),8));
s.docs.push({...d,id:'b',type:'bill',party:'s',lines:[{...d.lines[0],qty:5}]});
check('Supplier bill increments stock',()=>assert.equal(A.stock(s,'i'),13));
check('Overpayments rejected',()=>assert.throws(()=>A.validatePayment(s,{doc:'d',amount:237,date:'2026-11-02'}),/no greater/));
check('Payments before invoice rejected',()=>assert.throws(()=>A.validatePayment(s,{doc:'d',amount:1,date:'2026-10-31'}),/precede/));
s.payments.push({doc:'d',amount:100,date:'2026-11-02'});
check('Partial receipt balance',()=>assert.equal(A.balance(s,d),136));
s.expenses.push({date:'2026-11-05',amount:20});
check('P&L excludes GST and purchases',()=>assert.deepEqual(A.pnl(s,'2026-11-01','2026-11-30'),{sales:200,cost:120,expenses:20,profit:60}));
check('P&L period filter',()=>assert.equal(A.pnl(s,'2026-12-01','2026-12-31').profit,0));
s.payments[0].void=true;d.void=true;
check('Void reverses invoice stock and P&L',()=>{assert.equal(A.stock(s,'i'),15);assert.equal(A.pnl(s,'2026-11-01','2026-11-30').sales,0);assert.equal(A.paid(s,'d'),0)});
check('Invalid payment to void doc rejected',()=>assert.throws(()=>A.validatePayment(s,{doc:'d',amount:10,date:'2026-11-02'})));
check('Indian amount wording',()=>assert.equal(A.words(501334.8),'Five Lakh One Thousand Three Hundred Thirty Four Rupees and Eighty Paise Only'));
check('Two-decimal line tax rounding',()=>assert.equal(A.total({lines:[{qty:1,rate:424860,gst:18}]}).total,501334.8));


check('Stock retains three decimal places',()=>{const st={...s,items:[{id:'fraction',opening:1.005}],docs:[],adjustments:[]};assert.equal(A.stock(st,'fraction'),1.005)});

console.log(count+' accounting checks passed');
