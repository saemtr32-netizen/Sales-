@echo off
setlocal
cd /d "%~dp0"
if not defined ANDROID_HOME set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if not exist "%ANDROID_HOME%\platforms\android-35\android.jar" (
 echo Install Android SDK Platform 35 with Android Studio SDK Manager first.
 pause
 exit /b 1
)
if not defined JAVA_HOME if exist "%ProgramFiles%\Android\Android Studio\jbr" set "JAVA_HOME=%ProgramFiles%\Android\Android Studio\jbr"
set "NEXVANT_GRADLE_HOME=%~dp0.gradle-dist\gradle-8.9"
if not exist "%NEXVANT_GRADLE_HOME%\bin\gradle.bat" (
 powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; New-Item -ItemType Directory -Force '.gradle-dist' | Out-Null; $url='https://services.gradle.org/distributions/gradle-8.9-bin.zip'; Invoke-WebRequest $url -OutFile '.gradle-dist/gradle.zip'; $expected=(Invoke-WebRequest ($url+'.sha256')).Content.Trim(); $actual=(Get-FileHash '.gradle-dist/gradle.zip' -Algorithm SHA256).Hash; if ($actual -ine $expected) { throw 'Gradle checksum mismatch' }; Expand-Archive '.gradle-dist/gradle.zip' '.gradle-dist' -Force"
 if errorlevel 1 exit /b 1
)
call "%NEXVANT_GRADLE_HOME%\bin\gradle.bat" --no-daemon assembleDebug
if errorlevel 1 (
 echo Build failed. See the error above.
 pause
 exit /b 1
)
echo APK created at app\build\outputs\apk\debug\app-debug.apk
pause
