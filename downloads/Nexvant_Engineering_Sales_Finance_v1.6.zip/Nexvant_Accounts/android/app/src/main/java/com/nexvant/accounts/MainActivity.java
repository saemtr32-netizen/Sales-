package com.nexvant.accounts;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.print.PrintManager;
import android.webkit.*;
import android.view.WindowManager;
import android.widget.Toast;
import java.io.*;
import java.nio.charset.StandardCharsets;

/** Offline wrapper. Only the bundled page may load. No INTERNET permission. */
public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private String pendingBackup;
    private static final int OPEN_BACKUP = 11, SAVE_BACKUP = 12;
    private static final String ORIGIN = "https://appassets.androidplatform.net/index.html";
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        web = new WebView(this);
        setContentView(web);
        web.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(), insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets;
        });
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(true);
        web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new Printer(), "AndroidPrint");
        web.addJavascriptInterface(new Files(), "AndroidFiles");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) { return !ORIGIN.equals(req.getUrl().toString()); }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req) {
                try {
                    if (ORIGIN.equals(req.getUrl().toString())) return new WebResourceResponse("text/html", "UTF-8", getAssets().open("index.html"));
                } catch (IOException ignored) { }
                return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                startActivityForResult(intent, OPEN_BACKUP);
                return true;
            }
        });
        web.loadUrl(ORIGIN);
    }
    public class Printer {
        @JavascriptInterface public void printPage() {
            runOnUiThread(() -> ((PrintManager)getSystemService(PRINT_SERVICE)).print("Nexvant report", web.createPrintDocumentAdapter("Nexvant report"), null));
        }
    }
    public class Files {
        @JavascriptInterface public void saveBackup(String name, String contents) {
            runOnUiThread(() -> {
                if(pendingBackup != null) { Toast.makeText(MainActivity.this,"Complete the current save first",Toast.LENGTH_LONG).show(); return; }
                pendingBackup = contents;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, name);
                startActivityForResult(intent, SAVE_BACKUP);
            });
        }
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if(request == OPEN_BACKUP && chooser != null) {
            chooser.onReceiveValue(result == RESULT_OK && data != null ? new Uri[]{data.getData()} : null);
            chooser = null;
        }
        if(request == SAVE_BACKUP) {
            if(result == RESULT_OK && data != null && pendingBackup != null) {
                try(OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if(out == null) throw new IOException("Cannot open destination");
                    out.write(pendingBackup.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this,"Encrypted backup saved",Toast.LENGTH_LONG).show();
                } catch(IOException e) { Toast.makeText(this,"Could not save backup. Please try again.",Toast.LENGTH_LONG).show(); }
            }
            pendingBackup = null;
        }
    }
    @Override public void onBackPressed() {
        new android.app.AlertDialog.Builder(this).setMessage("Lock and close Nexvant Accounts?").setNegativeButton("Stay",null).setPositiveButton("Close",(d,w)->{web.evaluateJavascript("lock()",null);finish();}).show();
    }
    @Override protected void onDestroy() { if(web != null) { web.removeJavascriptInterface("AndroidPrint"); web.removeJavascriptInterface("AndroidFiles"); web.destroy(); } super.onDestroy(); }
}
